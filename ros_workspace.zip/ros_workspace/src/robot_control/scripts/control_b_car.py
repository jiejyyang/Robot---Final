#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Path
from nav_msgs.msg import Odometry
import tf
import math

class BCarController:
    def __init__(self):
        rospy.init_node('b_car_controller')
        self.cmd_vel_pub = rospy.Publisher('/b_car/cmd_vel', Twist, queue_size=10)
        self.path_sub = rospy.Subscriber('/a_car/path', Path, self.path_callback)
        self.path = None
        self.tf_listener = tf.TransformListener()
        self.current_index = 0

    def path_callback(self, msg):
        self.path = msg

    def run(self):
        rate = rospy.Rate(10)
        while not rospy.is_shutdown():
            if self.path is not None and self.current_index < len(self.path.poses):
                target_pose = self.path.poses[self.current_index].pose
                twist = Twist()
                
                twist.linear.x = 0.5  
                self.cmd_vel_pub.publish(twist)
                self.current_index += 1
            else:
                self.cmd_vel_pub.publish(Twist()) 
            rate.sleep()

if __name__ == '__main__':
    controller = BCarController()
    controller.run()
