#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Path
from std_msgs.msg import Bool
from nav_msgs.msg import Odometry
import tf
import math

class ACarController:
    def __init__(self):
        rospy.init_node('a_car_controller')
        self.cmd_vel_pub = rospy.Publisher('/a_car/cmd_vel', Twist, queue_size=10)
        self.path_pub = rospy.Publisher('/a_car/path', Path, queue_size=10)
        self.stop_sub = rospy.Subscriber('/stop_signal', Bool, self.stop_callback)
        self.path = Path()
        self.path.header.frame_id = "odom"
        self.stop = False
        self.odom_sub = rospy.Subscriber('/a_car/odom', Odometry, self.odom_callback)
        self.tf_listener = tf.TransformListener()

    def odom_callback(self, msg):
        pose = msg.pose.pose
        pose_stamped = PoseStamped()
        pose_stamped.header = msg.header
        pose_stamped.pose = pose
        self.path.poses.append(pose_stamped)
        self.path_pub.publish(self.path)

    def stop_callback(self, msg):
        self.stop = msg.data

    def run(self):
        rate = rospy.Rate(10)
        while not rospy.is_shutdown():
            if not self.stop:
                twist = Twist()
                twist.linear.x = 0.5  
                self.cmd_vel_pub.publish(twist)
            else:
                self.cmd_vel_pub.publish(Twist())  
            rate.sleep()

if __name__ == '__main__':
    controller = ACarController()
    controller.run()
